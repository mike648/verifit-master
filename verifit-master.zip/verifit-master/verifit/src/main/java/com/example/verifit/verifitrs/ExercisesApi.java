package com.example.verifit.verifitrs;

import android.content.Context;

public class ExercisesApi {

    Context context;
    String url;
    String username;
    String password;

    public ExercisesApi(Context context, String url, String username, String password)
    {
        this.context = context;
        this.url = url;
        this.username = username;
        this.password = password;
    }


    public void getExercise()
    {

    }

    public void postExercise()
    {

    }

    public void deleteExercise()
    {

    }

    public void updateExercise()
    {

    }

    public void getAllExercises()
    {

    }
}
