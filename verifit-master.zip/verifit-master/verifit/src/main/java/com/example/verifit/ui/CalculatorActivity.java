package com.example.verifit.ui;


import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import com.example.verifit.R;


// Plate Calculator and One Repetition Maximum Calculator
public class CalculatorActivity extends AppCompatActivity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculator);


    }

}